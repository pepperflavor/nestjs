export class VerifyEamilDto{
    signupVerifyToken: string;
}